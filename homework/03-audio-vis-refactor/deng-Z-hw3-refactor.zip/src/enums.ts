export enum AudioDefaults {
    GAIN = 5,
    DISTORTION = 0,
    PAN = 0,
    NUM_SAMPLES = 256
};

export enum DefaultSong {
    sound1 = "media/Blessing Song.mp3"
}