// helper function to get a random value from an array
export const getRandomFromArr = (arr) => arr[Math.floor(Math.random() * arr.length)];